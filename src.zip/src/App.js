import './App.css';
import ChatPage from './ChatPage/ChatPage';

function App() {
  return (
    <div className="App">
      <ChatPage />
    </div>
  );
}

export default App;
